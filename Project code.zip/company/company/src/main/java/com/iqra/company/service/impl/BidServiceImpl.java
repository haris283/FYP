package com.iqra.company.service.impl;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.Bid;
import com.iqra.company.entity.Company;
import com.iqra.company.entity.ProductsList;
import com.iqra.company.entity.Supplier;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.model.BidDetail;
import com.iqra.company.model.BidResult;
import com.iqra.company.repository.BidRepository;
import com.iqra.company.repository.SupplierRepository;
import com.iqra.company.service.BidService;

@Service
public class BidServiceImpl implements BidService{
	
	
	@Autowired
	private BidRepository bidRepository;
	@Autowired
	private SupplierRepository supplierRepository;
	@Override
	public Bid addBid(String supplierToken, int productId, double price) throws DuplicateEntityException{
		
		Supplier supplier=supplierRepository.findBytoken(supplierToken);
		int supplierId=supplier.getId();
		Bid bid=new Bid();
		ProductsList productsList=new ProductsList();
		
		boolean duplicateBid= bidRepository.findBysupplierIdAndProductsListId(supplierId,productId)!=null;

		//productsList=bid.getProductsList();
		
		//supplier=bid.getSupplier();
		
		if (duplicateBid)
		{
			throw new DuplicateEntityException("Bid already done!");
		}
		
		else 
		productsList.setId(productId);
		supplier.setId(supplierId);
		bid.setProductsList(productsList);
		bid.setSupplier(supplier);		
		bid.setPrice(price);		
		bid.setDate(java.time.LocalDate.now());

		return bidRepository.save(bid);
	}

	@Override
	public List<BidDetail> getAllBids(String supplierToken) {
		
		Supplier supplier=supplierRepository.findBytoken(supplierToken);
		int supplierId=supplier.getId();
		List<Bid> bids=bidRepository.findBysupplierId(supplierId);
		List<BidDetail> bidDetails=new ArrayList<BidDetail>();
		
		for(int i=0;i<bids.size();i++)
		{
			BidDetail bidDetail=new BidDetail();
						
			Bid bidsResult=bids.get(i);
			
			bidDetail.setProductTitle(bidsResult.getProductsList().getTitle());
			bidDetail.setBidPrice(bidsResult.getPrice());
			bidDetail.setBidDate(bidsResult.getDate());
			
			bidDetails.add(bidDetail);			
			
		}		
		
		return bidDetails;
		
	}

	@Override
	public List<BidResult> getBiddingResults(int productListId) {
	
		
		List<BidResult> bidResults= new ArrayList<>();
		
		List<Bid> bids=bidRepository.findByproductsListId(productListId);
		
		for (int i=0;i<bids.size();i++)
		{
			BidResult bidResult=new BidResult();
			
			Bid bidDetails=bids.get(i);			
			
			String fullname= bidDetails.getSupplier().getFirstName() +" "+ bidDetails.getSupplier().getLastName();
			
			bidResult.setPrice(bidDetails.getPrice());
			bidResult.setSupplierName(fullname);
			
			bidResults.add(bidResult);
		}
		
		
		return bidResults;
	}
	

}
