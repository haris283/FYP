package com.iqra.company.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.iqra.company.entity.Category;
import com.iqra.company.entity.Company;
import com.iqra.company.entity.ProductsList;
import com.iqra.company.entity.Supplier;
import com.iqra.company.entity.SupplierCategory;
import com.iqra.company.model.AddProductListRequest;
import com.iqra.company.model.BidResult;
import com.iqra.company.model.ProductDetail;
import com.iqra.company.repository.CompanyRepository;
import com.iqra.company.repository.ProductsListRepository;
import com.iqra.company.repository.SupplierRepository;
import com.iqra.company.service.ProductsListService;

@Service
public class ProductsListImpl implements ProductsListService{

	ProductsList productsList=new ProductsList();
	@Autowired
	private ProductsListRepository productsListRepository;
	@Autowired
	private SupplierRepository supplierRepository;
	@Autowired
	private CompanyRepository companyRepository;
	@Override
	public ProductsList addProduct(AddProductListRequest addProductsList) {
		//TODO: Add business logic here.
		Company company=companyRepository.findBysignupToken(addProductsList.getCompanyToken());
		Category category=new Category();
		int companyId=company.getId();
		
		category.setId(addProductsList.getCategoryId());
		
		productsList.setTitle(addProductsList.getTitle());
		productsList.setDescription(addProductsList.getDescription());
		productsList.setCompanyId(companyId);
		productsList.setCategory(category);
		productsList.setPublishedAt(java.time.LocalDate.now());
		
		return productsListRepository.save(productsList);
	}
	@Override
	public Iterable<ProductsList> getAllProductsByCategoryIds(String supplierToken) {	
		Supplier supplier=supplierRepository.findBytoken(supplierToken);
		
		List<SupplierCategory> supplierCategories=supplier.getCategories();
		System.out.println("Category ids: "+supplierCategories);
		
		List <Integer> catregoryIds = new ArrayList();
		for(SupplierCategory supplierCategory: supplierCategories)
		{
			
			supplierCategory.getCategory().getId();		
			catregoryIds.add(supplierCategory.getCategory().getId());
		}
		//List<String> strCategoryIds= categoryIds.li;
		//List<Integer> intCategoryIds=Integer.parseInt(strCategoryIds);
		
		List<ProductsList> productsList= productsListRepository.findBycategoryIdIn(catregoryIds);
		
		return productsListRepository.findBycategoryIdIn(catregoryIds);
		
	}
	
	@Override
	public List<ProductDetail> getPastOrders(String companyToken) {
		
		Company company=companyRepository.findBysignupToken(companyToken);
		int companyId=company.getId();
		
		List<ProductsList> productsList= productsListRepository.findBycompanyId(companyId);
		List<ProductDetail> productDetails=new ArrayList<ProductDetail>();
		
		
		for (int i=0;i<productsList.size();i++)
		{
			ProductDetail productDetail=new ProductDetail();
			
			ProductsList productCredentials= productsList.get(i);		
			//productCredentials.getBids().get(i).getSupplier().getFirstName()
			
			productDetail.setProductDescription(productCredentials.getDescription());
			productDetail.setProductTitle(productCredentials.getTitle());
			productDetail.setPublishedDate(productCredentials.getPublishedAt());
			
			productDetails.add(productDetail);
		
		}

		return productDetails;		
		
	}
	
	public void deleteItem(int id) {		
    	
		productsListRepository.deleteById(id);
	}
	@Override
	public ProductsList updateTitle(int id, String title) {
		Optional<ProductsList> titleOptional=productsListRepository.findById(id);
		
		if(titleOptional.isPresent()) {
			ProductsList productsList= titleOptional.get();
			productsList.setTitle(title);
			return productsListRepository.save(productsList);
			
		}
		
		 throw new RuntimeException("Invalid title");
	}
	@Override
	public ProductsList updateDescription(int id, String description) {
		Optional<ProductsList> descriptionOptional=productsListRepository.findById(id);
		
		if(descriptionOptional.isPresent()) {
			ProductsList productsList= descriptionOptional.get();
			productsList.setDescription(description);
			return productsListRepository.save(productsList);
	}
		throw new RuntimeException("Invalid description");

	}
	
	
}
