package com.iqra.company.service;

import java.util.List;

import com.iqra.company.entity.Bid;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.model.BidDetail;
import com.iqra.company.model.BidResult;

public interface BidService {
	
	Bid addBid(String supplierToken, int productId, double price) throws DuplicateEntityException;
	List<BidDetail> getAllBids(String supplierToken);
	public List<BidResult> getBiddingResults(int productListId);

}
