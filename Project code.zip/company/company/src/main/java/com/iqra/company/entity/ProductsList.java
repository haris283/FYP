package com.iqra.company.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "products_list")
public class ProductsList {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	private int id;
	@Column(name = "title")
	private String title;
	@Column(name = "description")
	private String description;
	@Column(name = "company_id")
	private int companyId; // foreign key
	@Column(name = "published_date")
	private LocalDate publishedAt;
	@JsonIgnore
	@OneToMany
	private List<Bid> bids;
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY, cascade =  CascadeType.MERGE)
	private Category category;
		
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int company_id) {
		this.companyId = company_id;
	}
	public LocalDate getPublishedAt() {
		return publishedAt;
	}
	public void setPublishedAt(LocalDate publishedAt) {
		this.publishedAt = publishedAt;
	}
	public List<Bid> getBids() {
		return bids;
	}
	public void setBids(List<Bid> bids) {
		this.bids = bids;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	
}
