package com.iqra.company.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.iqra.company.entity.ProductsList;
@Repository

public interface ProductsListRepository extends CrudRepository<ProductsList,Integer>{
	
	public List<ProductsList> findBycategoryIdIn(List<Integer> categoryIds);
	public List<ProductsList> findBycompanyId(int companyId);

}
