package com.iqra.company.model;

public class AddProductListRequest {
	
	String title;
	String description;
	String companyToken;
	int categoryId;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCompanyToken() {
		return companyToken;
	}
	public void setCompanyToken(String companyToken) {
		this.companyToken = companyToken;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	
}
