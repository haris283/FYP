package com.iqra.company.service;

import org.springframework.http.ResponseEntity;


public interface LoginService {
	
	ResponseEntity<String> login(String username, String password);

}
