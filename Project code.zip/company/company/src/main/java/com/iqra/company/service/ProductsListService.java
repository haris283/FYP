package com.iqra.company.service;

import java.util.List;


import com.iqra.company.entity.ProductsList;
import com.iqra.company.model.AddProductListRequest;
import com.iqra.company.model.BidResult;
import com.iqra.company.model.ProductDetail;

public interface ProductsListService {
	
	ProductsList addProduct(AddProductListRequest productsList);
	void deleteItem(int id);
	ProductsList updateTitle(int id, String title);
	ProductsList updateDescription(int id, String description);
	public Iterable<ProductsList> getAllProductsByCategoryIds(String supplierToken);
	public List<ProductDetail> getPastOrders(String companyToken);
	 
}
