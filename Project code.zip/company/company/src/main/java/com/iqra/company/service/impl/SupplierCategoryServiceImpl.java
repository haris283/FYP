package com.iqra.company.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.Category;
import com.iqra.company.entity.Supplier;
import com.iqra.company.entity.SupplierCategory;
import com.iqra.company.repository.SupplierCategoryRepository;
import com.iqra.company.service.SupplierCategoryService;


@Service
public class SupplierCategoryServiceImpl implements SupplierCategoryService{
	
	
	@Autowired
	private SupplierCategoryRepository supplierCategoryRepository;
	
	SupplierCategory supplierCategory=new SupplierCategory();
	Supplier supplier=new Supplier();
	Category category=new Category();	

	@Override
	public SupplierCategory registerSupplier(int supplierId, List<Integer> supplierCategories) {
		
		for (int i=0;i<supplierCategories.size();i++)
		{
			category.setId(supplierCategories.get(i));
		}
		supplier.setId(supplierId);
		
		
		supplierCategory.setSupplier(supplier);
		supplierCategory.setCategory(category);
		
		return supplierCategoryRepository.save(supplierCategory);
	}

}