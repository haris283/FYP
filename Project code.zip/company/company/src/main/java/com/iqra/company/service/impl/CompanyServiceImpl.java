package com.iqra.company.service.impl;

import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.Company;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.model.AddCompanyRequest;
import com.iqra.company.repository.CompanyRepository;
import com.iqra.company.repository.SupplierRepository;
import com.iqra.company.service.CompanyService;

@Service
public class CompanyServiceImpl implements CompanyService{
	
	@Autowired
	private SupplierRepository supplierRepository;	
	@Autowired
	private CompanyRepository companyRepository;

	@Override
	public Company registerCompany(AddCompanyRequest addCompanyRequest) throws DuplicateEntityException{
		boolean uniqueUsername= supplierRepository.findByuserName(addCompanyRequest.getUsername())==null && companyRepository.findByUsername(addCompanyRequest.getUsername())==null;
		Company company=new Company();
		Random rand = new Random();
	    int intRandom = rand.nextInt(99999); 
	    String strRandom=Integer.toString(intRandom);
		
		if (uniqueUsername)
		{
			company.setUsername(addCompanyRequest.getUsername());	
		} 
		else
		{
			throw new DuplicateEntityException("Username already exists! Please try another one.");
		}
		
		if(addCompanyRequest.getPassword().equals(addCompanyRequest.getConfirmPassword()))
		{
			company.setPassword(addCompanyRequest.getPassword());
		}
		
		else
		{
			throw new DuplicateEntityException("Password does not match!");
		}
		company.setName(addCompanyRequest.getName());
		company.setEmail(addCompanyRequest.getEmail());		
		company.setSignupToken("COM-"+strRandom);
		
		return companyRepository.save(company);
	
	}

	@Override
	public Iterable<Company> getAllCompanies() {
		return companyRepository.findAll();
	}

	
	public void deleteCompany(int id) {		
    	
		companyRepository.deleteById(id);		
	}
	

	@Override
	public Company updateName(int id, String name) {
		
		Optional<Company> compOptional=companyRepository.findById(id);
		
		if(compOptional.isPresent()) {
			Company company= compOptional.get();
			company.setName(name);
			return companyRepository.save(company);
	}
		 throw new RuntimeException("Invalid company");

	
	}
}
