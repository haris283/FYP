package com.iqra.company.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.Company;
import com.iqra.company.entity.Supplier;
import com.iqra.company.repository.CompanyRepository;
import com.iqra.company.repository.SupplierRepository;
import com.iqra.company.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	SupplierRepository supplierRepository;
	@Autowired
	CompanyRepository companyRepository;	
	
	@Override
	public ResponseEntity<String> login(String username, String password) 
	{
		boolean supplierLogin=supplierRepository.findByuserNameAndPassword(username, password)!=null;
		boolean companyLogin=companyRepository.findByusernameAndPassword(username, password)!=null;
		boolean adminLogin= username.equals("admin") && password.equals("admin");
		
		if (supplierLogin)
		{
			Supplier supplier= supplierRepository.findByuserName(username);
			return new ResponseEntity<String>(supplier.getToken(), HttpStatus.OK);
		}
		
		if(companyLogin)
		{
			Company company=companyRepository.findByUsername(username);
			return new ResponseEntity<String>(company.getSignupToken(), HttpStatus.OK);
		}
		
		if(adminLogin)
		{
			return new ResponseEntity<String>("admin", HttpStatus.OK);
		}
		
		else 
			
			return new ResponseEntity<String>("Invalid login. Please try again!", HttpStatus.BAD_REQUEST);
	}

}
