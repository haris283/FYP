package com.iqra.company.repository;

import org.springframework.data.repository.CrudRepository;

import com.iqra.company.entity.Category;

public interface CategoryRepository extends CrudRepository<Category,Integer> 
{
	
	public Category findByName(String name);	

}
