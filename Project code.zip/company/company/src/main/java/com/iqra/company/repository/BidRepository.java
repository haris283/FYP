package com.iqra.company.repository;

import org.springframework.data.repository.CrudRepository;

import com.iqra.company.entity.Bid;
import java.util.*;

public interface BidRepository extends CrudRepository<Bid, Integer>{
	
    public List<Bid> findBysupplierId(int supplierId);
    public Bid findBysupplierIdAndProductsListId(int supplierId, int productId);
    public List<Bid>findByproductsListId(int productId);

}
