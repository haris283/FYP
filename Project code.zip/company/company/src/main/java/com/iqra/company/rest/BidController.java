package com.iqra.company.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.iqra.company.entity.Bid;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.model.BidDetail;
import com.iqra.company.model.BidResult;
import com.iqra.company.service.BidService;

@Controller 
@RequestMapping(path="/bid") 
public class BidController {
	@Autowired 
	private BidService bidService;
	
	
	@PostMapping("/addBid/{supplierToken}/{productId}")
	  public @ResponseBody Bid addBid (@RequestParam String supplierToken, @RequestParam int productId, @RequestParam double price) throws DuplicateEntityException{

		return bidService.addBid(supplierToken, productId,price);
		
	  }
	
	  @GetMapping("/biddingResults")
	  public @ResponseBody List<BidResult> getBiddingResults(@RequestParam int productListId)
	  {
			return bidService.getBiddingResults(productListId);
	  }

	  @GetMapping("/myBids/{supplierToken}")
	  public @ResponseBody List<BidDetail> getAllBids(@RequestParam String supplierToken) {
	    return bidService.getAllBids(supplierToken);
	    
	  
	}
	

	
}
