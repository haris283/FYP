package com.iqra.company.service;


import java.util.List;


import com.iqra.company.entity.SupplierCategory;

public interface SupplierCategoryService {
	
	SupplierCategory registerSupplier(int supplierId, List<Integer> supplierCategories);

}
