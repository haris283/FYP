package com.iqra.company.service.impl;

import com.iqra.company.entity.Category;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.repository.CategoryRepository;
import com.iqra.company.service.CategoryService;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service

public class CategoryServiceImpl implements CategoryService {

	Category category=new Category();
	@Autowired
	private CategoryRepository categoryRepository;
	@Override
	public Category addCategory(String name) throws DuplicateEntityException {
		//TODO: Add business logic here.
		
		
		boolean duplicate = categoryRepository.findByName(name)!=null;
		
		if (duplicate) {
			throw new DuplicateEntityException(name+" already exists");
		}
		
		else {
		category.setName(name);
		return categoryRepository.save(category);
		}
	}
	
	@Override
	public Iterable<Category> getAllCategories() {		
    	
    	return categoryRepository.findAll();     

		
	}
	
	public void deleteCategory(int id) {		
    	
		categoryRepository.deleteById(id);		
	}
	@Override
	public Category updateCategory(int id, String name) throws DuplicateEntityException{
		boolean duplicate = categoryRepository.findByName(name)!=null;

		if (duplicate) {
			throw new DuplicateEntityException(name+" already exists");
		}
		
		Optional<Category> categOptional=categoryRepository.findById(id);
		
		if(categOptional.isPresent()) {
			Category category= categOptional.get();
			category.setName(name);
			return categoryRepository.save(category);
			
			
			
			
		}
		
		 throw new RuntimeException("Invalid category");
	}
	
	

}
