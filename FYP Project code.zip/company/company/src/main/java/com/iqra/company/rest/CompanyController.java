package com.iqra.company.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.iqra.company.entity.Company;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.model.AddCompanyRequest;
import com.iqra.company.service.CompanyService;

@Controller 
@RequestMapping(path="/company") 
public class CompanyController {
	
	@Autowired 
	private CompanyService companyService;
	
	@PostMapping
	  public @ResponseBody Company registerCompany (@RequestBody AddCompanyRequest addCompanyRequest) throws DuplicateEntityException{

		return companyService.registerCompany(addCompanyRequest);
		
	  }

	  @GetMapping
	  public @ResponseBody Iterable<Company> getAllCompanies() {
	    return companyService.getAllCompanies();
	  }
	

	@DeleteMapping("/{id}")
	public @ResponseBody ResponseEntity<String> delete(@PathVariable  int id) {
		companyService.deleteCompany(id);
	    return ResponseEntity.ok(""+id+" Deleted succesfully!");
	}
	
	@PutMapping("/{id}")
	public @ResponseBody Company updateName(@PathVariable int id, @RequestParam String name) {
	    return companyService.updateName(id, name);
	}


}
