package com.iqra.company.repository;

import org.springframework.data.repository.CrudRepository;

import com.iqra.company.entity.Company;

public interface CompanyRepository extends CrudRepository<Company, Integer>{
	
	public Company findByUsername(String username);
	public Company findByusernameAndPassword(String username, String pasword);	


}
