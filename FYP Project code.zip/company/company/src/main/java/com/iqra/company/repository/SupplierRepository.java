package com.iqra.company.repository;

import org.springframework.data.repository.CrudRepository;

import com.iqra.company.entity.Supplier;
import com.iqra.company.model.AddSupplierRequest;

public interface SupplierRepository extends CrudRepository<Supplier,Integer>{
	
	public Supplier findByuserName(String username);
	

}
