package com.iqra.company.service;

import com.iqra.company.entity.SupplierCategory;

public interface SupplierCategoryService {
	
	SupplierCategory registerSupplier(int supplier_id, int category_id);

}
