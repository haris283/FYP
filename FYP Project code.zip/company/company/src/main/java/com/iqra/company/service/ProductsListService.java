package com.iqra.company.service;

import org.springframework.http.ResponseEntity;

import com.iqra.company.entity.Category;
import com.iqra.company.entity.ProductsList;
import com.iqra.company.entity.SupplierCategory;

public interface ProductsListService {
	
	ProductsList addProduct(String title, String description, int companyId, int categoryId);
	void deleteItem(int id);
	ProductsList updateTitle(int id, String title);
	ProductsList updateDescription(int id, String description);
	public Iterable<ProductsList> getAllItemsByCategoryIds(String supplierToken);
	//public ResponseEntity<String> getAllItemsByCategoryIds(String supplierToken);
	 
}
