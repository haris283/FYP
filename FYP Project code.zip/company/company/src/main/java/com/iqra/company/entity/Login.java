/*package com.iqra.company.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "credential")
public class Login {
	
	@Column(name = "username")
	private String username;
	@Column(name = "login_password")
	private String loginPassword;
	@Column(name = "type")
	private String type;
	@Column(name = "login_token")
	private String loginToken;
	@Column(name = "identifer")
	private int identifer;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getLoginPassword() {
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLoginToken() {
		return loginToken;
	}
	public void setLoginToken(String loginToken) {
		this.loginToken = loginToken;
	}
	public int getIdentifer() {
		return identifer;
	}
	public void setIdentifer(int identifer) {
		this.identifer = identifer;
	}
	
}*/
