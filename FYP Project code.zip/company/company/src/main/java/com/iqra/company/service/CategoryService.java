package com.iqra.company.service;


import com.iqra.company.entity.Category;
import com.iqra.company.exception.DuplicateEntityException;


public interface CategoryService {

	Category addCategory(String name) throws DuplicateEntityException;
	Iterable<Category> getAllCategories();
	void deleteCategory(int id);
	Category updateCategory(int id, String name);
	
}
