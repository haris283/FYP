package com.iqra.company.service;

import org.springframework.http.ResponseEntity;

import com.iqra.company.entity.Login;
import com.iqra.company.exception.DuplicateEntityException;

public interface LoginService {
	
	ResponseEntity<String> login(String username, String password);

}
