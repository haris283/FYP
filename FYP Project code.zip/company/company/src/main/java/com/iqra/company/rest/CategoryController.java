package com.iqra.company.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.iqra.company.entity.Category;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.service.CategoryService;

@Controller 
@RequestMapping(path="/categories") 
public class CategoryController {
	@Autowired 
	private CategoryService categoryService;
	
	
	@PostMapping
	  public @ResponseBody Category addNewCategory (@RequestParam String name) throws DuplicateEntityException {

		return categoryService.addCategory(name);
		
	  }

	  @GetMapping
	  public @ResponseBody Iterable<Category> getAllCategories() {
	    return categoryService.getAllCategories();
	  }
	

	@DeleteMapping("/{id}")
	public @ResponseBody ResponseEntity<String> delete(@PathVariable  int id) {
		categoryService.deleteCategory(id);
	    return ResponseEntity.ok(""+id+" Deleted succesfully!");
	}
	
	@PutMapping("/{id}")
	public @ResponseBody Category updateCategory(@PathVariable int id, @RequestParam String name) {
	    return categoryService.updateCategory(id, name);
	}
	
}
