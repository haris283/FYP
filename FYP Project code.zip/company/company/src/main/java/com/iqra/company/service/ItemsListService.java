package com.iqra.company.service;

import com.iqra.company.entity.ItemsList;

public interface ItemsListService {
	
	ItemsList addItem(String title, String description);
	Iterable<ItemsList> getAllItems();
	void deleteItem(int id);
	ItemsList updateTitle(int id, String title);
	ItemsList updateDescription(int id, String description);

}
