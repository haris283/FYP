package com.iqra.company.rest;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.iqra.company.entity.Supplier;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.model.AddSupplierRequest;
import com.iqra.company.service.SupplierService;
import com.iqra.company.entity.Category;

@Controller 
@RequestMapping(path="/supplier") 
public class SupplierController {
	
	private static final String String = null;
	@Autowired 
	private SupplierService supplierService;
	
	@PostMapping
	public @ResponseBody Supplier registerSupplier(@RequestBody AddSupplierRequest addSupplierRequest) throws DuplicateEntityException
	{
		return supplierService.registerSupplier(addSupplierRequest);
	}

	  @GetMapping("/{token}")
	  public @ResponseBody Iterable<Supplier> getAllSuppliers(@PathVariable String token)
	  {
		  return supplierService.getAllSuppliers();
				  
	  }
	

	@DeleteMapping("/{id}")
	public @ResponseBody ResponseEntity<String> delete(@PathVariable  int id) {
		supplierService.deleteSupplier(id);
		return ResponseEntity.ok(""+id+" Supplier Deleted succesfully!");
	}
	
	@PutMapping("/{id}")
	public Supplier updateName(@PathVariable int id,@PathVariable String firstName,@PathVariable String lastName)
	{
		return supplierService.updateSupplierName(id, firstName, lastName);
	}
	
	/*@PutMapping("/{id}")
	public Supplier updateEmail(@PathVariable int id,@PathVariable String email)
	{
		return supplierService.updateSupplierEmail(id, email);
	}*/


}
