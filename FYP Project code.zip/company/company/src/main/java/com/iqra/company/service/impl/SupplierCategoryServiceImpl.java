package com.iqra.company.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.SupplierCategory;
import com.iqra.company.repository.SupplierCategoryRepository;
import com.iqra.company.service.SupplierCategoryService;

@Service
public class SupplierCategoryServiceImpl implements SupplierCategoryService{
	
	SupplierCategory supplierCategory;
	@Autowired
	private SupplierCategoryRepository supplierCategoryRepository;

	@Override
	public SupplierCategory registerSupplier(int supplier_id, int category_id) {
		
		supplierCategory.setCategory_id(category_id);
		supplierCategory.setSupplier_id(supplier_id);
		
		return supplierCategoryRepository.save(supplierCategory);
	}

}
