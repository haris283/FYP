package com.iqra.company.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.Category;
import com.iqra.company.entity.SupplierCategory;
import com.iqra.company.repository.SupplierCategoryRepository;
import com.iqra.company.service.SupplierCategoryService;


@Service
public class SupplierCategoryServiceImpl implements SupplierCategoryService{
	
	
	@Autowired
	private SupplierCategoryRepository supplierCategoryRepository;
	
	

	@Override
	public SupplierCategory registerSupplier(int supplierId, int categoryId) {
		
		SupplierCategory supplierCategory=new SupplierCategory();
		supplierCategory.setSupplierId(supplierId);
		supplierCategory.setCategoryId(categoryId);
		
		return supplierCategoryRepository.save(supplierCategory);
	}

}