package com.iqra.company.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.Category;
import com.iqra.company.entity.Company;
import com.iqra.company.entity.Supplier;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.model.AddSupplierRequest;
import com.iqra.company.repository.CompanyRepository;
import com.iqra.company.repository.SupplierRepository;
import com.iqra.company.service.SupplierService;


@Service
public class SupplierServiceImpl implements SupplierService{

	
	
	@Autowired
	private SupplierRepository supplierRepository;	
	@Autowired
	private CompanyRepository companyRepository; 
	
    Random rand = new Random();
    Integer int_random = rand.nextInt(99999); 
    String stringToken=int_random.toString();

	@Override
	public Supplier registerSupplier(AddSupplierRequest addSupplierRequest) throws DuplicateEntityException{
	
	Supplier supplier=new Supplier();
	Company company=new Company();	
	
	boolean uniqueUsername= supplierRepository.findByuserName(addSupplierRequest.getUserName())==null && companyRepository.findByUsername(addSupplierRequest.getUserName())==null;
	
	if (uniqueUsername)
	{
		supplier.setUserName(addSupplierRequest.getUserName());

	} 
	else
	{
		throw new DuplicateEntityException("Username already exists! Please try another one.");
	}
	
		supplier.setFirstName(addSupplierRequest.getFirstname());	
		supplier.setLastName(addSupplierRequest.getLastname());
		supplier.setEmail(addSupplierRequest.getEmail());
		supplier.setPassword(addSupplierRequest.getPassword());
		supplier.setToken(stringToken);
		
		
		return supplierRepository.save(supplier);
	}

	@Override
	public Iterable<Supplier> getAllSuppliers() {
		
		return null;
	}

	@Override
	public void deleteSupplier(int id) {
		supplierRepository.deleteById(id);
		
	}

	@Override
	public Supplier updateSupplierName(int id, String firstName, String lastName) {
		
		Optional<Supplier> supplierOptional=supplierRepository.findById(id);
		
		if(supplierOptional.isPresent())
		{
			Supplier supplier=supplierOptional.get();
			supplier.setFirstName(firstName);
			supplier.setLastName(lastName);
			
			return supplierRepository.save(supplier);
			
		}
		throw new RuntimeException("Invalid supplier");
		
	}

	@Override
	public Supplier updateSupplierEmail(int id, String email) {
		
		Optional<Supplier> supplierOptional=supplierRepository.findById(id);
		
		if(supplierOptional.isPresent())
		{
			Supplier supplier=supplierOptional.get();
			supplier.setEmail(email);
			
			return supplierRepository.save(supplier);
			
		}
		throw new RuntimeException("Invalid supplier");
	}

}
