package com.iqra.company.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.iqra.company.service.SupplierCategoryService;

@Controller 
@RequestMapping(path="/supplier_category") 
public class SupplierCategoryController {
	
	@Autowired
	SupplierCategoryService supplierCategoryService;
	
	@PostMapping
	  public @ResponseBody SupplierCategoryService addNewCategory (@RequestParam int supplier_id, @RequestParam int category_id) {

		return (SupplierCategoryService) supplierCategoryService.registerSupplier(supplier_id, category_id);
		
	  }

}
