package com.iqra.company.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.Company;
import com.iqra.company.entity.ItemsList;
import com.iqra.company.repository.ItemsListRepository;
import com.iqra.company.service.ItemsListService;

@Service
public class ItemsListImpl implements ItemsListService{
	Company company;
	
	@Autowired
	private ItemsListRepository itemsListRepository;
	@Override
	public ItemsList addItem(String title, String description) {
		//TODO: Add business logic here.
		ItemsList itemsList=new ItemsList();
		itemsList.setTitle(title);
		itemsList.setDescription(description);
		//itemsList.setCompany_id(company.getId());
		return itemsListRepository.save(itemsList);
	}
	@Override
	public Iterable<ItemsList> getAllItems() {		
    	
    	return itemsListRepository.findAll();     

		
	}
	
	
	public void deleteItem(int id) {		
    	
		itemsListRepository.deleteById(id);
	}
	@Override
	public ItemsList updateTitle(int id, String title) {
		Optional<ItemsList> titleOptional=itemsListRepository.findById(id);
		
		if(titleOptional.isPresent()) {
			ItemsList itemsList= titleOptional.get();
			itemsList.setTitle(title);
			return itemsListRepository.save(itemsList);
			
			
			
			
		}
		
		 throw new RuntimeException("Invalid title");
	}
	@Override
	public ItemsList updateDescription(int id, String description) {
		Optional<ItemsList> descriptionOptional=itemsListRepository.findById(id);
		
		if(descriptionOptional.isPresent()) {
			ItemsList itemsList= descriptionOptional.get();
			itemsList.setDescription(description);
			return itemsListRepository.save(itemsList);
	}
		throw new RuntimeException("Invalid description");

	}
}
