package com.iqra.company.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.Company;
import com.iqra.company.entity.Login;
import com.iqra.company.entity.Supplier;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.repository.CompanyRepository;
import com.iqra.company.repository.SupplierRepository;
import com.iqra.company.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	SupplierRepository supplierRepository;
	@Autowired
	CompanyRepository companyRepository;	
	
	@Override
	public ResponseEntity<String> login(String username, String password) 
	{
		boolean supplierLogin=supplierRepository.findByuserName(username)!=null;
		boolean companyLogin=companyRepository.findByUsername(username)!=null;
		
		if(supplierLogin)
		{
			Supplier supplier=supplierRepository.findByuserNameAndPassword(username, password);
			//Integer intSupplierToken= supplier.getToken();
			String supplierToken=supplier.getToken();
					
			if(supplier!=null)
			{
				return new ResponseEntity<String>(supplierToken, HttpStatus.OK);
				
			}
		}
		
		if(companyLogin)	
		{
			Company company=companyRepository.findByusernameAndPassword(username, password);
			Integer intCompanyToken=company.getSignupToken();
			String stringCompanyToken=intCompanyToken.toString();
			
			if(company!=null)
			{
				return new ResponseEntity<String>(stringCompanyToken, HttpStatus.OK);
			}
		}
		
		
		else 
		
			return new ResponseEntity<String>("Invalid login. Please try again!", HttpStatus.BAD_REQUEST);
		return null;
	}

}
