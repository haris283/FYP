package com.iqra.company.service.impl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.Bid;
import com.iqra.company.repository.BidRepository;
import com.iqra.company.service.BidService;

@Service
public class BidServiceImpl implements BidService{
	
	@Autowired
	private BidRepository bidRepository;
	@Override
	public Bid addBid(double price) {
		Bid bid=new Bid();
		bid.setPrice(price);
		return null;
	}

	@Override
	public Iterable<Bid> getAllBids() {
		return bidRepository.findAll();
	}

	@Override
	public void deleteBid(int id) {
		bidRepository.deleteById(id);
		
	}

}
