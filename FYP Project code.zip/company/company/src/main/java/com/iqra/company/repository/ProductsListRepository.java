package com.iqra.company.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.iqra.company.entity.ProductsList;
import com.iqra.company.entity.SupplierCategory;
@Repository

public interface ProductsListRepository extends CrudRepository<ProductsList,Integer>{
	
	List<ProductsList> findBycategoryIdIn(List<SupplierCategory> categoryIds);
	

}
