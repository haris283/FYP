package com.iqra.company.exception;

import org.springdoc.api.ErrorMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GlobalException extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(DuplicateEntityException.class)
    public ResponseEntity<ErrorMessage> handleDuplicateEntityException(DuplicateEntityException ex) {

		ErrorMessage message = new ErrorMessage(ex.getMessage());
		        
		    
		    return new ResponseEntity<ErrorMessage>(message, HttpStatus.OK);
     }

}
