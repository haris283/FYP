package com.iqra.company.service;

import com.iqra.company.entity.Supplier;

public interface SupplierService {
	
	Supplier registerSupplier(String name, String email);
	Iterable<Supplier> getAllSuppliers();
	void deleteSupplier(int id);
	Supplier updateSupplierName(int id, String name);
	Supplier updateSupplierEmail(int id, String email);
	

}
