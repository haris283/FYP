package com.iqra.company.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "supplier-category")
public class SupplierCategory {
	
	private int id;
	private int supplier_id; //foreign key
	private int category_id; //foreign key
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSupplier_id() {
		return supplier_id;
	}
	public void setSupplier_id(int supplier_id) {
		this.supplier_id = supplier_id;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	
	

}
