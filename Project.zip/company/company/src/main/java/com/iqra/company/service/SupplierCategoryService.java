package com.iqra.company.service;

public interface SupplierCategoryService {

}
