package com.iqra.company.repository;

import org.springframework.data.repository.CrudRepository;

import com.iqra.company.entity.SupplierCategory;

public interface SupplierCategoryRepository extends CrudRepository<SupplierCategory, Integer>{

}
