package com.iqra.company.repository;

import org.springframework.data.repository.CrudRepository;
import com.iqra.company.entity.ItemsList;

public interface ItemsListRepository extends CrudRepository<ItemsList,Integer>{

}
