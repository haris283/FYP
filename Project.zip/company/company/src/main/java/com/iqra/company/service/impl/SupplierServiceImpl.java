package com.iqra.company.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.iqra.company.entity.Supplier;
import com.iqra.company.repository.SupplierCategoryRepository;
import com.iqra.company.repository.SupplierRepository;
import com.iqra.company.service.SupplierService;

public class SupplierServiceImpl implements SupplierService{

	@Autowired
	private SupplierRepository supplierRepository;
	@Autowired
	private SupplierCategoryRepository supplierCategoryRepository;
	
	@Override
	public Supplier registerSupplier(String name, String email) {
		Supplier supplier=new Supplier();
		supplier.setName(name);
		supplier.setEmail(email);
		
		return supplierRepository.save(supplier);
	}

	@Override
	public Iterable<Supplier> getAllSuppliers() {
		
		return supplierRepository.findAll();
	}

	@Override
	public void deleteSupplier(int id) {
		supplierRepository.deleteById(id);
		
	}

	@Override
	public Supplier updateSupplierName(int id, String name) {
		
		Optional<Supplier> supplierOptional=supplierRepository.findById(id);
		
		if(supplierOptional.isPresent())
		{
			Supplier supplier=supplierOptional.get();
			supplier.setName(name);
			
			return supplierRepository.save(supplier);
			
		}
		throw new RuntimeException("Invalid supplier");
		
	}

	@Override
	public Supplier updateSupplierEmail(int id, String email) {
		
		Optional<Supplier> supplierOptional=supplierRepository.findById(id);
		
		if(supplierOptional.isPresent())
		{
			Supplier supplier=supplierOptional.get();
			supplier.setEmail(email);
			
			return supplierRepository.save(supplier);
			
		}
		throw new RuntimeException("Invalid supplier");
	}

}
