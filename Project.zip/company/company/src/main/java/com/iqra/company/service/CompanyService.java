package com.iqra.company.service;

import com.iqra.company.entity.Company;

public interface CompanyService {

	
	Company addCompany(String name);
	Iterable<Company> getAllCompanies();
	void deleteCompany(int id);
	Company updateName(int id, String name);
}
