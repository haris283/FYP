package com.iqra.company.service.impl;

public class SupplierCategoryServiceImpl {

}
