package com.iqra.company.service.impl;

import com.iqra.company.entity.Category;
import com.iqra.company.repository.CategoryRepository;
import com.iqra.company.service.CategoryService;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service

public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryRepository categoryRepository;
	@Override
	public Category addCategory(String name) {
		//TODO: Add business logic here.
		Category category=new Category();
		category.setActive(true);
		category.setName(name);
		return categoryRepository.save(category);
	}
	@Override
	public Iterable<Category> getAllCategories() {		
    	
    	return categoryRepository.findAll();     

		
	}
	
	
	public void deleteCategory(int id) {		
    	
		categoryRepository.deleteById(id);		
	}
	@Override
	public Category updateCategory(int id, String name) {
		Optional<Category> categOptional=categoryRepository.findById(id);
		
		if(categOptional.isPresent()) {
			Category category= categOptional.get();
			category.setName(name);
			return categoryRepository.save(category);
			
			
			
			
		}
		
		 throw new RuntimeException("Invalid category");
	}
	
	

}
