package com.iqra.company.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.Category;
import com.iqra.company.entity.Company;
import com.iqra.company.repository.CompanyRepository;
import com.iqra.company.service.CompanyService;

@Service
public class CompanyServiceImpl implements CompanyService{
	
	@Autowired
	private CompanyRepository companyRepository;

	@Override
	public Company addCompany(String name) {
		Company company=new Company();
		company.setName(name);
		
		return companyRepository.save(company);
	
	}

	@Override
	public Iterable<Company> getAllCompanies() {
		return companyRepository.findAll();
	}

	
	public void deleteCompany(int id) {		
    	
		companyRepository.deleteById(id);		
	}
	

	@Override
	public Company updateName(int id, String name) {
		
		Optional<Company> compOptional=companyRepository.findById(id);
		
		if(compOptional.isPresent()) {
			Company company= compOptional.get();
			company.setName(name);
			return companyRepository.save(company);
	}
		 throw new RuntimeException("Invalid company");

	
	}
}
