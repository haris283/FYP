package com.iqra.company.service;

import com.iqra.company.entity.Bid;

public interface BidService {
	
	Bid addBid(double price);
	Iterable<Bid> getAllBids();
	void deleteBid(int id);

}
