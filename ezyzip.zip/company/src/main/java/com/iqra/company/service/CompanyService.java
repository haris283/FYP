package com.iqra.company.service;

import com.iqra.company.entity.Company;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.model.AddCompanyRequest;

public interface CompanyService {

	
	Company registerCompany(AddCompanyRequest addCompanyRequest) throws DuplicateEntityException;
	Iterable<Company> getAllCompanies();
	void deleteCompany(int id);
	Company updateName(int id, String name);
}
