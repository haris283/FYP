package com.iqra.company.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.iqra.company.entity.Category;
import com.iqra.company.entity.ProductsList;
import com.iqra.company.service.ProductsListService;

@Controller 
@RequestMapping(path="/productsList") 
public class ProductsListController {
	
	@Autowired 
	private ProductsListService productsListService;
	
	
	@PostMapping
	public @ResponseBody ProductsList addProduct(@RequestParam String title,@RequestParam String description,@RequestParam int companyId, @RequestParam int categoryId)
	{
		return productsListService.addProduct(title, description, companyId, categoryId);
	}

	@GetMapping("/{token}")
	public @ResponseBody Iterable<ProductsList> getAllItems(@RequestParam String token)
	{
		return productsListService.getAllProductsByCategoryIds(token);
	}
	

	@DeleteMapping("/{id}")
	public @ResponseBody ResponseEntity<String> delete(@PathVariable  int id) {
		productsListService.deleteItem(id);
		return ResponseEntity.ok(""+id+" Deleted succesfully!");
	}
	
	@PutMapping("/{id}")
	public ProductsList updateTitle(@PathVariable int id,@PathVariable String title)
	{
		return productsListService.updateTitle(id, title);
	}
	
	/*@PutMapping("/{id}")
	public ItemsList updateDescription(@PathVariable int id,@PathVariable String description)
	{
		return itemsListService.updateDescription(id, description);
	}*/


}
