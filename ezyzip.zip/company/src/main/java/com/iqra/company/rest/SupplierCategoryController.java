package com.iqra.company.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.iqra.company.entity.Category;
import com.iqra.company.entity.SupplierCategory;
import com.iqra.company.service.SupplierCategoryService;


@Controller 
@RequestMapping(path="/supplier_category") 
public class SupplierCategoryController {
	
	@Autowired
	SupplierCategoryService supplierCategoryService;
	
	@PostMapping
	  public @ResponseBody SupplierCategory addNewCategory (@RequestParam int supplierId, @RequestParam int categoryId) {

		return (SupplierCategory) supplierCategoryService.registerSupplier(supplierId, categoryId);
		
	  }

}