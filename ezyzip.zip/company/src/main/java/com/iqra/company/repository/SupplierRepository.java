package com.iqra.company.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.iqra.company.entity.Supplier;

public interface SupplierRepository extends CrudRepository<Supplier,Integer>{
	
	public Supplier findByuserName(String username);
	public Supplier findByuserNameAndPassword(String username, String pasword);	
	public Supplier findBytoken(String token);
	
}
