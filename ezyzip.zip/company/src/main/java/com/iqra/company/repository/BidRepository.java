package com.iqra.company.repository;

import org.springframework.data.repository.CrudRepository;

import com.iqra.company.entity.Bid;

public interface BidRepository extends CrudRepository<Bid, Integer>{

}
