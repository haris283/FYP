package com.iqra.company.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "products_list")
public class ProductsList {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	private int id;
	@Column(name = "title")
	private String title;
	@Column(name = "description")
	private String description;
	@Column(name = "company_id")
	private int company_id; // foreign key
	@Column(name = "category_id")
	private int categoryId; // foreign key
	@Column(name = "published_date")
	private LocalDate publishedAt;
	/*@OneToOne(fetch = FetchType.LAZY, cascade =  CascadeType.ALL)
	private Category category;*/
		
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getCompany_id() {
		return company_id;
	}
	public void setCompany_id(int company_id) {
		this.company_id = company_id;
	}
	/*public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}*/
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public LocalDate getPublishedAt() {
		return publishedAt;
	}
	public void setPublishedAt(LocalDate publishedAt) {
		this.publishedAt = publishedAt;
	}
	
}
