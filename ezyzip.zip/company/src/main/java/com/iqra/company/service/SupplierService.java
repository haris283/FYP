package com.iqra.company.service;


import java.util.List;

import com.iqra.company.entity.Category;
import com.iqra.company.entity.Supplier;
import com.iqra.company.exception.DuplicateEntityException;
import com.iqra.company.model.AddSupplierRequest;

public interface SupplierService {
	
	Supplier registerSupplier(AddSupplierRequest addSupplierRequest) throws DuplicateEntityException;
	Iterable<Supplier> getAllSuppliers();
	void deleteSupplier(int id);
	Supplier updateSupplierName(int id, String firstName, String lastName);
	Supplier updateSupplierEmail(int id, String email);
	

}
