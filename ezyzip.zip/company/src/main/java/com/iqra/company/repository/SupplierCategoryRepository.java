package com.iqra.company.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.iqra.company.entity.SupplierCategory;

@Repository
public interface SupplierCategoryRepository extends CrudRepository<SupplierCategory, Integer>{

}