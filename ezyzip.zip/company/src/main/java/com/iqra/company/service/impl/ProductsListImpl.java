package com.iqra.company.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.iqra.company.entity.Category;
import com.iqra.company.entity.Company;
import com.iqra.company.entity.ProductsList;
import com.iqra.company.entity.Supplier;
import com.iqra.company.entity.SupplierCategory;
import com.iqra.company.repository.ProductsListRepository;
import com.iqra.company.repository.SupplierRepository;
import com.iqra.company.service.ProductsListService;

@Service
public class ProductsListImpl implements ProductsListService{
	//Company company;
	
	@Autowired
	private ProductsListRepository productsListRepository;
	@Autowired
	private SupplierRepository supplierRepository;
	@Override
	public ProductsList addProduct(String title, String description, int companyId, int categoryId) {
		//TODO: Add business logic here.
		ProductsList productsList=new ProductsList();
		productsList.setTitle(title);
		productsList.setDescription(description);
		productsList.setCompany_id(companyId);
		productsList.setCategoryId(categoryId);
		productsList.setPublishedAt(java.time.LocalDate.now());
		
		return productsListRepository.save(productsList);
	}
	@Override
	public Iterable<ProductsList> getAllProductsByCategoryIds(String supplierToken) {	
		Supplier supplier=supplierRepository.findBytoken(supplierToken);
		
		List<SupplierCategory> supplierCategories=supplier.getCategories();
		System.out.println("Category ids: "+supplierCategories);
		
		List <Integer> catregoryIds = new ArrayList();
		for(SupplierCategory supplierCategory: supplierCategories)
		{
			
			supplierCategory.getCategory().getId();		
			catregoryIds.add(supplierCategory.getCategory().getId());
			}
		//List<String> strCategoryIds= categoryIds.li;
		//List<Integer> intCategoryIds=Integer.parseInt(strCategoryIds);
		
		List<ProductsList> productsList= productsListRepository.findBycategoryIdIn(catregoryIds);
		
		return productsListRepository.findBycategoryIdIn(catregoryIds);
		
		
		//return productsList;				
    	//Supplierservice.getsupplierbytoken(token);
		//supplier.getSuppliercategs();
		//findAllByCategoryIds(List<Integer> categoryIds);
		//yaha hamara pass saree products aaa gaee
    
		/*return productsListRepository.findBycategoryId(supplierCategories);*/
		//return new ResponseEntity<String>("", HttpStatus.OK);

		
	}
	
	public void deleteItem(int id) {		
    	
		productsListRepository.deleteById(id);
	}
	@Override
	public ProductsList updateTitle(int id, String title) {
		Optional<ProductsList> titleOptional=productsListRepository.findById(id);
		
		if(titleOptional.isPresent()) {
			ProductsList productsList= titleOptional.get();
			productsList.setTitle(title);
			return productsListRepository.save(productsList);
			
			
			
			
		}
		
		 throw new RuntimeException("Invalid title");
	}
	@Override
	public ProductsList updateDescription(int id, String description) {
		Optional<ProductsList> descriptionOptional=productsListRepository.findById(id);
		
		if(descriptionOptional.isPresent()) {
			ProductsList productsList= descriptionOptional.get();
			productsList.setDescription(description);
			return productsListRepository.save(productsList);
	}
		throw new RuntimeException("Invalid description");

	}
}
